#!/bin/sh

#----------------------------------------------------------------------------------------------
# Uninstall settings
#----------------------------------------------------------------------------------------------
. gettext.sh
export TEXTDOMAIN="q4os-devpack"

unset LC_ALL
unset LANGUAGE
LANG="C"

APN="q4os-nomacs"
APD="Nomacs"
APF="$( echo $APN | awk '{ print substr(toupper($0),1,1) substr($0,2) }' )"
MSG_01="<p>You are going to uninstall <b>"$APD"</b> software, do you really want it ?</p><p>You need to be member of administrative group \"sudo\" to do this action. You can safely cancel "$APD" uninstallation now, or enter your password to proceed ...</p>"
MSG_02="<b>"$APD"</b> has been uninstalled. Done."
EMSG_01="Package system is busy, not ready to uninstall now. Setup cannot continue.\nThe lock is caused, very probably, by ongoing background system updates. If this is the case, you have to wait a moment for package system to finish these operations. Please make sure you are not installing another application and repeat setup few minutes later.\nCleaning and canceling now ..."
EMSG_02="Error uninstalling application, please inform your system administrator. Cleaning and canceling now ..."
#RUN_COMM_AFTER_SETUP="/opt/program_files/$APN/bin/application.exu" # run command after install

SUDO_PROMPT=""

#----------------------------------------------------------------------------------------------
# Initialize
#----------------------------------------------------------------------------------------------
echo " --- Uninstalling $APD ---"
echo "[UNINST] >> Initializing .."
WORKDIR=$(mktemp -d --tmpdir=/tmp --suffix=-q4appuninstall)
cd $WORKDIR

#----------------------------------------------------------------------------------------------
# Check if application could be uninstalled
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Checking $APD status .."
PKGSTATUS=$( dpkg -s $APN 2>&1 | grep "install ok installed" ) #todo: replace later with 'dash /usr/share/apps/q4os_system/bin/print_package_version.sh $APN'
if [ -n "$PKGSTATUS" ] ; then
 echo "[UNINST] >> $APD could be uninstalled .. Ok"
else
 echo "[UNINST] >> $APD couldn't be uninstalled .. FAIL !"
 kdialog --title "Uninstall" --caption "$APD" --icon "package_settings" --error "$APD application is not installed, so canceling uninstallation ..."
 cd .. ; rm -rf $WORKDIR
 sleep 1 ; exit 1
fi

#----------------------------------------------------------------------------------------------
# Check pksys
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Checking package system .."
check_apt_busy.sh
if [ "$?" != "0" ] ; then
 echo "[UNINST] >> Package system not ready .. EXIT !"
 kdialog --title "$APD setup " --caption "Warning !" --icon "package_settings" --sorry "$EMSG_01"
 sleep 1 ; exit 1
fi
echo "[UNINST] >> Package system ready .. Ok"

#----------------------------------------------------------------------------------------------
# Confirm uninstall, get password
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Waiting for sudo password .."
SUDO_PASS="$(kdialog --title "Password" --caption "" --icon "package_settings" --password "$MSG_01")"
RCANSWER=$?
if [ "${RCANSWER}" = "0" ] ; then
 echo "[UNINST] >> Password entered .. Checking"
else
 echo "[UNINST] >> Canceled .. EXIT !"
 cd .. ; rm -rf $WORKDIR
 sleep 1 ; exit 1
fi

#----------------------------------------------------------------------------------------------
# Check password
#----------------------------------------------------------------------------------------------
sudo -k
( echo "$SUDO_PASS" | sudo -p "" -S echo 2>&1 ) > /dev/null
if [ "$?" != "0" ] ; then
 SUDO_PASS=""
 echo "[UNINST] >> Bad password .. FAIL !"
 kdialog --title "Error !" --caption "" --icon "package_settings" --error "You don't have admin rights, canceling ..."
 cd .. ; rm -rf $WORKDIR
 sleep 1 ; exit 1
else
 SUDO_PASS=""
 echo "answered .. Ok"
 echo "[UNINST] >> Password .. Ok"
fi

#----------------------------------------------------------------------------------------------
# Checking pksys
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Looking for pksys locks .."
check_apt_busy.sh
if [ "$?" != "0" ] ; then
 echo "[UNINST] >> Package system not ready .. EXIT !"
 kdialog --title "$APD setup " --caption "Warning !" --icon "package_settings" --sorry "$EMSG_01"
 sleep 1 ; exit 1
fi
echo "[UNINST] >> No locks found .. Ok"
#
# echo "[UNINST] >> Locking package system .."
# get locks here !!!
# qapt-lock &
# if not then error
# echo "[UNINST] >> Package couldn't be locked .. FAIL !"
# echo "[UNINST] >> Package system locked .. Ok"
#
echo "[UNINST] >> Refreshing package system .."
echo "$SUDO_PASS" | sudo -S dpkg --force-confold --configure -a
echo "[UNINST] >> Testing package system .."
APTSTATUS=$( echo "$SUDO_PASS" | sudo -S apt-get check -q -q 2>&1 )
if [ -n "$APTSTATUS" ] ; then
 echo "[UNINST] >> Package system not ready .. EXIT !"
 kdialog --title "$APD setup " --caption "Warning !" --icon "package_settings" --sorry "$EMSG_01"
 sleep 1 ; exit 1
fi
echo "[UNINST] >> Package system seems good .. Ok"

#----------------------------------------------------------------------------------------------
# Running custom pre-uninstall scripts
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Checking pre-uninstall scripts .."
if [ -f "/usr/share/apps/q4os_system/uninst_q4inf/pre-uninst1_$APN.sh" ] ; then
 echo "[UNINST] >> Sourcing pre-uninstall script \"pre-uninst1_$APN.sh\" .."
 . /usr/share/apps/q4os_system/uninst_q4inf/pre-uninst1_$APN.sh
fi
if [ -f "/usr/share/apps/q4os_system/uninst_q4inf/pre-uninst2_$APN.sh" ] ; then
 echo "[UNINST] >> Running pre-uninstall script \"pre-uninst2_$APN.sh\" .."
 echo "$SUDO_PASS" | sudo -S dash /usr/share/apps/q4os_system/uninst_q4inf/pre-uninst2_$APN.sh
fi

#----------------------------------------------------------------------------------------------
# Uninstalling
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Uninstalling $APD .."
ADDUNST_FL="/usr/share/apps/q4os_system/uninst_q4inf/addpacks_uninst_$APN.lst"
# ADDUNST_FL="/usr/share/apps/q4os_system/q4_regs/$APN.qrg" #todo: prefer to read 'uninstall_addpacks' record from .qrg file
if [ -f "$ADDUNST_FL" ] ; then
 WANTED_UNINST_PCKS="$( cat "$ADDUNST_FL" | tr '\n' ' ' | sed 's/, / /g' )"
 # WANTED_UNINST_PCKS="$( kreadconfig --file="$ADDUNST_FL" --group="Global" --key="uninstall_addpacks" | sed 's/, / /g' )"
 ADDUNST_PCKS="$( LANG="C" dpkg --get-selections $WANTED_UNINST_PCKS 2>/dev/null | tr '\t' ' ' | grep -v " deinstall$" | grep " install$" | awk -F' ' '{ print $1 }' | sort -u | tr '\n' ' ' )"
 if [ -n "$ADDUNST_PCKS" ] ; then
  echo "[UNINST] >> Removing additional packages: $ADDUNST_PCKS"
 else
  unset ADDUNST_PCKS
 fi
fi
echo "$SUDO_PASS" | sudo -S apt-get --assume-yes --auto-remove -o Apt::AutoRemove::SuggestsImportant=false remove $APN $ADDUNST_PCKS #todo: try command "autoremove" instead of "remove" ; todo: try switch: -o Apt::AutoRemove::RecommendsImportant=false
echo "[UNINST] >> Uninstalling .. Done"

#----------------------------------------------------------------------------------------------
# Running custom post-uninstall scripts
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Checking post-uninstall scripts .."
if [ -f "/usr/share/apps/q4os_system/uninst_q4inf/post-uninst1_$APN.sh" ] ; then
 echo "[UNINST] >> Sourcing post-uninstall script \"post-uninst1_$APN.sh\" .."
 . /usr/share/apps/q4os_system/uninst_q4inf/post-uninst1_$APN.sh
fi
if [ -f "/usr/share/apps/q4os_system/uninst_q4inf/post-uninst2_$APN.sh" ] ; then
 echo "[UNINST] >> Running post-uninstall script \"post-uninst2_$APN.sh\" .."
 echo "$SUDO_PASS" | sudo -S dash /usr/share/apps/q4os_system/uninst_q4inf/post-uninst2_$APN.sh
fi

#----------------------------------------------------------------------------------------------
# Check if application was uninstalled correctly
#----------------------------------------------------------------------------------------------
echo "[UNINST] >> Checking environment .."
PKGSTATUS=$( dpkg -s $APN 2>&1 | grep "install ok installed" ) #todo: replace later with 'dash /usr/share/apps/q4os_system/bin/print_package_version.sh $APN'
if [ -n "$PKGSTATUS" ] ; then {
 echo "[UNINST] >> Uninstallation was not succesfull .. ERROR !"
 kdialog --title "Error !" --caption "" --icon "package_settings" --error "$EMSG_02"
 cd .. ; rm -rf $WORKDIR
 sleep 1 ; exit 1
}
else {
 echo "[UNINST] >> Uninstallation succesfully finished .. Ok"
}
fi

#----------------------------------------------------------------------------------------------
# Clean and finish
#----------------------------------------------------------------------------------------------
kdialog --title "Uninstall" --caption "$APD" --icon "package_settings" --msgbox "$MSG_02" #todo: make it ontop window
cd .. ; rm -rf $WORKDIR
